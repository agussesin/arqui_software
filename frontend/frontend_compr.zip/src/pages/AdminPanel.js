export default function Home() {
  return <h1>Vista Home</h1>;
}
